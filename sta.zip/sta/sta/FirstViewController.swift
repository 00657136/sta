//
//  FirstViewController.swift
//  sta
//
//  Created by User06 on 2019/5/13.
//  Copyright © 2019 bear. All rights reserved.
//

import UIKit
import SafariServices
import UserNotifications
class FirstViewController: UIViewController,SFSafariViewControllerDelegate {

    @IBOutlet weak var JisooImage: UIImageView!
    @IBOutlet weak var LisaImage: UIImageView!
    @IBOutlet weak var JennieImage: UIImageView!
    @IBOutlet weak var RoseImage: UIImageView!
    
    var i:Int=0
 
    /*override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let controller = segue.destination as! ViewController
        controller.pickCharacter = pick
    }*/
    override func viewDidLoad() {
        super.viewDidLoad()
        timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { (_) in
            if self.i == 1{
                self.i -= 1
                self.JisooImage.image = #imageLiteral(resourceName: "jisoo2")
                self.LisaImage.image = #imageLiteral(resourceName: "Lisa2")
                self.JennieImage.image = #imageLiteral(resourceName: "jennie2")
                self.RoseImage.image = #imageLiteral(resourceName: "rose2")
            }
            else{
                self.i += 1
                self.JisooImage.image = #imageLiteral(resourceName: "jisoo1")
                self.LisaImage.image = #imageLiteral(resourceName: "Lisa1")
                self.JennieImage.image = #imageLiteral(resourceName: "jennie1")
                self.RoseImage.image = #imageLiteral(resourceName: "rose1")

            }
        }
        timer2 = Timer.scheduledTimer(withTimeInterval: 1, repeats: true, block: { (_) in
            if self.JisooImage.frame.origin.x == 500 {
                self.JisooImage.frame.origin = CGPoint(x:0,y: self.JisooImage.frame.origin.y)
            }
            if self.LisaImage.frame.origin.x == 500 {
                self.LisaImage.frame.origin = CGPoint(x:0,y: self.LisaImage.frame.origin.y)
            }
            if self.JennieImage.frame.origin.x == 500 {
                self.JennieImage.frame.origin = CGPoint(x:0,y: self.JennieImage.frame.origin.y)
            }
            if self.RoseImage.frame.origin.x == 500 {
                self.RoseImage.frame.origin = CGPoint(x:0,y: self.RoseImage.frame.origin.y)
            }
            else{
                 UIViewPropertyAnimator.runningPropertyAnimator(withDuration: 1,delay: 0,options:[.repeat],animations:{self.JisooImage.frame.origin = CGPoint(x:500,y: self.JisooImage.frame.origin.y)})
                UIViewPropertyAnimator.runningPropertyAnimator(withDuration: 1,delay: 0,options:[.repeat],animations:{self.LisaImage.frame.origin = CGPoint(x:500,y: self.LisaImage.frame.origin.y)})
                UIViewPropertyAnimator.runningPropertyAnimator(withDuration: 1,delay: 0,options:[.repeat],animations:{self.JennieImage.frame.origin = CGPoint(x:500,y: self.JennieImage.frame.origin.y)})
                UIViewPropertyAnimator.runningPropertyAnimator(withDuration: 1,delay: 0,options:[.repeat],animations:{self.RoseImage.frame.origin = CGPoint(x:500,y: self.RoseImage.frame.origin.y)})
            }
        })
        /*UIViewPropertyAnimator.runningPropertyAnimator(withDuration: 3.5,delay: 0,options:[.repeat],animations:{self.JisooImage.frame.origin = CGPoint(x:500,y: self.JisooImage.frame.origin.y)})
           //self.JisooImage.frame.origin = CGPoint(x:0,y: 358)
        
       
        if JisooImage.frame.origin.x == 500 {
            JisooImage.frame.origin = CGPoint(x:0,y: JisooImage.frame.origin.y)
        }*/
        
        // Do any additional setup after loading the view.
    }
    var timer:Timer?
    var timer2:Timer?

    @IBAction func Link(_ sender: Any) {
        if let url = URL(string: "https://medium.com/@jeff.797886") {
            let safari = SFSafariViewController(url: url)
            safari.delegate = self
            present(safari,animated: true,completion: nil)
        }
    }
    @IBAction func readme(_ sender: Any) {
        let content = UNMutableNotificationContent()
        content.title = "遊戲說明"
        content.subtitle = "選擇一位blackpink成員成為你的夥伴"
        content.body = "藍鍵：開始／暫停，粉鍵：重置，綠鍵：往左，黃鍵：往右，吃到金幣會往上，一旦角色碰到天花板或地板，遊戲就結束了，看你能可以撐多久！"
        content.badge = 1
      
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 10, repeats: false)
        let request = UNNotificationRequest(identifier: "notification1", content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
