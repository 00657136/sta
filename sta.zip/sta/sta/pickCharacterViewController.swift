//
//  pickCharacterViewController.swift
//  sta
//
//  Created by User15 on 2019/5/14.
//  Copyright © 2019 bear. All rights reserved.
//

import UIKit


class pickCharacterViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    var pickNumber:Int?
    @IBAction func selectLisa(_ sender: Any) {
        pickNumber = 0
    }
    @IBAction func selectJennie(_ sender: Any) {
        pickNumber = 1
    }
    @IBAction func selectJisoo(_ sender: Any) {
        pickNumber = 2
    }
    @IBAction func selectRose(_ sender: Any) {
        pickNumber = 3
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let controller = segue.destination as! ViewController
        controller.pickCharacter = pickNumber
    }
 
    
    @IBAction func sendbuttom(_ sender: Any) {
        if pickNumber != 0 && pickNumber != 1 && pickNumber != 2 && pickNumber != 3{
            let controller = UIAlertController(title: "怎麼可以忘了!", message: "你忘了選一個blackpink成員，不選就不能玩喔！快回去選吧～", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            controller.addAction(okAction)
            present(controller, animated: true, completion: nil)
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
